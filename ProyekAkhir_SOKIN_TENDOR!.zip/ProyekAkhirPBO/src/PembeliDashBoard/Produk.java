/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PembeliDashBoard;

/**
 *
 * @author Ridho Gymnastiar Al Rasyid
 */
public class Produk extends PemilihanKomponen implements ItemProduk{

    public Produk() {
        super();
    }

    @Override
    public String[] getProcie() {
        return super.getProcie();
    }

    @Override
    public String[] getMobo() {
        return super.getMobo();
    }

    @Override
    public String[] getRam() {
        return super.getRam();
    }

    @Override
    public String[] getStorage1() {
        return super.getStorage1();
    }

    @Override
    public String[] getStorage2() {
        return super.getStorage2();
    }

    @Override
    public String[] getPsu() {
        return super.getPsu();
    }

    @Override
    public String[] getVga() {
        return super.getVga();
    }

    @Override
    public String[] getCasing() {
        return super.getCasing();
    }

}
