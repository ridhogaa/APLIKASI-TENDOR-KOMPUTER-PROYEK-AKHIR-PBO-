/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package PembeliDashBoard;

/**
 *
 * @author Ridho Gymnastiar Al Rasyid
 */
public interface ItemProduk {

    public String[] getProcie();

    public String[] getMobo();

    public String[] getRam();

    public String[] getStorage1();

    public String[] getStorage2();

    public String[] getPsu();

    public String[] getVga();

    public String[] getCasing();
}
